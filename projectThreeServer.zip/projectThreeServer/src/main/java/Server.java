//Neha Kamat, nkama4, UIN:665218217

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Server extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        // load the first screen
        Parent root = FXMLLoader.load(getClass().getResource("/server.fxml"));
        Scene scene = new Scene(root, 600, 400);
        scene.getStylesheets().add(getClass().getResource("/server.css").toExternalForm());
        
        primaryStage.setTitle("3 Card Poker Server");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}