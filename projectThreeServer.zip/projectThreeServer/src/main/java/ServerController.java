//Neha Kamat, nkama4, UIN:665218217

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerController {
    
    // stuff for intro screen
    @FXML
    private TextField portField;
    
    @FXML
    private Button startButton;
    
    // stuff for game screen
    @FXML
    private ListView<String> messageList;
    
    @FXML
    private Label clientCountLabel;
    
    @FXML
    private Button stopButton;
    
    private ServerSocket serverSocket;
    private boolean serverRunning = false;
    private int clientCount = 0;
    
    // starts the server when button is clicked
    @FXML
    private void startServer() {
        String portText = portField.getText();
        
        if (portText.isEmpty()) {
            System.out.println("Please enter a port number");
            return;
        }
        
        try {
            int port = Integer.parseInt(portText);
            
            // make a new thread for server
            Thread serverThread = new Thread(() -> {
                try {
                    serverSocket = new ServerSocket(port);
                    serverRunning = true;
                    
                    Platform.runLater(() -> {
                        System.out.println("Server started on port " + port);
                        switchToGameScreen();
                    });
                    
                    // keep accepting new clients
                    while (serverRunning) {
                        Socket clientSocket = serverSocket.accept();
                        clientCount++;
                        
                        // make thread for each client using ClientHandler
                        ClientHandler clientHandler = new ClientHandler(clientSocket, clientCount, this);
                        Thread thread = new Thread(clientHandler);
                        thread.start();
                        
                        int finalCount = clientCount;
                        Platform.runLater(() -> {
                            addMessage("Client #" + finalCount + " connected");
                            updateClientCount(clientCount);
                        });
                    }
                } catch (IOException e) {
                    if (serverRunning) {
                        e.printStackTrace();
                    }
                }
            });
            
            serverThread.start();
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid port number");
        }
    }
    
    // go to the game screen
    private void switchToGameScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/game.fxml"));
            loader.setController(this);
            Parent root = loader.load();
            
            Scene scene = new Scene(root, 800, 600);
            scene.getStylesheets().add(getClass().getResource("/server.css").toExternalForm());
            
            Stage stage = (Stage) startButton.getScene().getWindow();
            stage.setScene(scene);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // add message to the list view
    public void addMessage(String message) {
        Platform.runLater(() -> {
            if (messageList != null) {
                messageList.getItems().add(message);
                messageList.scrollTo(messageList.getItems().size() - 1);
            }
        });
    }
    
    // update how many clients connected
    public void updateClientCount(int count) {
        Platform.runLater(() -> {
            if (clientCountLabel != null) {
                clientCountLabel.setText("Connected Clients: " + count);
            }
        });
    }
    
    // stop the server
    @FXML
    private void stopServer() {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverRunning = false;
                serverSocket.close();
                addMessage("Server stopped");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
