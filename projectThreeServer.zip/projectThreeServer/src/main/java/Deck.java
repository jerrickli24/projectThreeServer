//Neha Kamat, nkama4, UIN:665218217

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> cards;
    private int currentCard;
    
    public Deck() {
        cards = new ArrayList<>();
        currentCard = 0;
        
        // make a deck with all 52 cards
        char[] suits = {'C', 'D', 'H', 'S'};
        
        for (char suit : suits) {
            for (int value = 2; value <= 14; value++) {
                cards.add(new Card(suit, value));
            }
        }
    }
    
    // shuffle cards
    public void shuffle() {
        Collections.shuffle(cards);
        currentCard = 0;
    }
    
    // deal 3 cards
    public ArrayList<Card> dealHand() {
        ArrayList<Card> hand = new ArrayList<>();
        
        for (int i = 0; i < 3; i++) {
            if (currentCard < cards.size()) {
                hand.add(cards.get(currentCard));
                currentCard++;
            }
        }
        
        return hand;
    }
}