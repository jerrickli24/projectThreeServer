//Neha Kamat, nkama4, UIN:665218217

import java.io.Serializable;
import java.util.ArrayList;

public class PokerInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String action;
    private int anteBet;
    private int pairPlusBet;
    private int playBet;
    private ArrayList<Card> playerHand;
    private ArrayList<Card> dealerHand;
    private int winnings;
    private String message;
    
    public PokerInfo() {
        this.playerHand = new ArrayList<>();
        this.dealerHand = new ArrayList<>();
    }
    
    // getters and setters
    public String getAction() {
        return action;
    }
    
    public void setAction(String action) {
        this.action = action;
    }
    
    public int getAnteBet() {
        return anteBet;
    }
    
    public void setAnteBet(int anteBet) {
        this.anteBet = anteBet;
    }
    
    public int getPairPlusBet() {
        return pairPlusBet;
    }
    
    public void setPairPlusBet(int pairPlusBet) {
        this.pairPlusBet = pairPlusBet;
    }
    
    public int getPlayBet() {
        return playBet;
    }
    
    public void setPlayBet(int playBet) {
        this.playBet = playBet;
    }
    
    public ArrayList<Card> getPlayerHand() {
        return playerHand;
    }
    
    public void setPlayerHand(ArrayList<Card> playerHand) {
        this.playerHand = playerHand;
    }
    
    public ArrayList<Card> getDealerHand() {
        return dealerHand;
    }
    
    public void setDealerHand(ArrayList<Card> dealerHand) {
        this.dealerHand = dealerHand;
    }
    
    public int getWinnings() {
        return winnings;
    }
    
    public void setWinnings(int winnings) {
        this.winnings = winnings;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
}