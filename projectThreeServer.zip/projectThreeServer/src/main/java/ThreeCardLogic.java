//Neha Kamat, nkama4, UIN:665218217

import java.util.ArrayList;
import java.util.Collections;

public class ThreeCardLogic {
    
    // figure out what hand the player has
    // returns: 0=high card, 1=pair, 2=flush, 3=straight, 4=three of kind, 5=straight flush
    public static int evalHand(ArrayList<Card> hand) {
        if (hand.size() != 3) {
            return 0;
        }
        
        // sort cards by value
        ArrayList<Card> sorted = new ArrayList<>(hand);
        Collections.sort(sorted, (a, b) -> a.getValue() - b.getValue());
        
        boolean isFlush = checkFlush(sorted);
        boolean isStraight = checkStraight(sorted);
        boolean isThreeKind = checkThreeOfKind(sorted);
        boolean isPair = checkPair(sorted);
        
        if (isStraight && isFlush) {
            return 5;
        }
        if (isThreeKind) {
            return 4;
        }
        if (isStraight) {
            return 3;
        }
        if (isFlush) {
            return 2;
        }
        if (isPair) {
            return 1;
        }
        
        return 0;
    }
    
    // calculate how much pair plus bet wins
    public static int evalPPWinnings(ArrayList<Card> hand, int bet) {
        int handRank = evalHand(hand);
        
        switch (handRank) {
            case 5:
                return bet * 40; // straight flush
            case 4:
                return bet * 30; // three of kind
            case 3:
                return bet * 6; // straight
            case 2:
                return bet * 3; // flush
            case 1:
                return bet * 1; // pair
            default:
                return -bet; // lose
        }
    }
    
    // compare dealer hand vs player hand
    // returns: 0=tie, 1=dealer wins, 2=player wins
    public static int compareHands(ArrayList<Card> dealer, ArrayList<Card> player) {
        int dealerRank = evalHand(dealer);
        int playerRank = evalHand(player);
        
        if (playerRank > dealerRank) {
            return 2;
        } else if (dealerRank > playerRank) {
            return 1;
        } else {
            // same hand rank, check high cards
            return compareHighCards(dealer, player);
        }
    }
    
    // check if all same suit
    private static boolean checkFlush(ArrayList<Card> hand) {
        char suit = hand.get(0).getSuit();
        return hand.get(1).getSuit() == suit && hand.get(2).getSuit() == suit;
    }
    
    // check if cards in order
    private static boolean checkStraight(ArrayList<Card> hand) {
        int v1 = hand.get(0).getValue();
        int v2 = hand.get(1).getValue();
        int v3 = hand.get(2).getValue();
        
        return (v2 == v1 + 1 && v3 == v2 + 1);
    }
    
    // check if all three cards same value
    private static boolean checkThreeOfKind(ArrayList<Card> hand) {
        return hand.get(0).getValue() == hand.get(1).getValue() && 
               hand.get(1).getValue() == hand.get(2).getValue();
    }
    
    // check if two cards same value
    private static boolean checkPair(ArrayList<Card> hand) {
        int v1 = hand.get(0).getValue();
        int v2 = hand.get(1).getValue();
        int v3 = hand.get(2).getValue();
        
        return v1 == v2 || v2 == v3 || v1 == v3;
    }
    
    // compare high cards when same hand type
    private static int compareHighCards(ArrayList<Card> dealer, ArrayList<Card> player) {
        ArrayList<Card> dealerSorted = new ArrayList<>(dealer);
        ArrayList<Card> playerSorted = new ArrayList<>(player);
        
        // sort highest to lowest
        Collections.sort(dealerSorted, (a, b) -> b.getValue() - a.getValue());
        Collections.sort(playerSorted, (a, b) -> b.getValue() - a.getValue());
        
        for (int i = 0; i < 3; i++) {
            if (playerSorted.get(i).getValue() > dealerSorted.get(i).getValue()) {
                return 2;
            } else if (dealerSorted.get(i).getValue() > playerSorted.get(i).getValue()) {
                return 1;
            }
        }
        
        return 0;
    }
}