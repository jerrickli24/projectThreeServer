//Neha Kamat, nkama4, UIN:665218217

public class ServerMain {
    
    public static void main(String[] args) {
        // just launch the server application
        Server.main(args);
    }
}