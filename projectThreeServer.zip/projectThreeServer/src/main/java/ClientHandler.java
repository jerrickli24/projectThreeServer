//Neha Kamat, nkama4, UIN:665218217

import javafx.application.Platform;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ClientHandler implements Runnable {
    
    private Socket socket;
    private int clientId;
    private ServerController controller;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private Deck deck;
    private ArrayList<Card> dealerHand;
    private ArrayList<Card> playerHand;
    
    public ClientHandler(Socket socket, int clientId, ServerController controller) {
        this.socket = socket;
        this.clientId = clientId;
        this.controller = controller;
        this.deck = new Deck();
    }
    
    @Override
    public void run() {
        try {
            // setup input/output streams
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            
            // keep playing games
            while (true) {
                // get info from client
                PokerInfo betInfo = (PokerInfo) in.readObject();
                
                if (betInfo.getAction().equals("PLACE_BET")) {
                    // shuffle and deal cards
                    deck.shuffle();
                    dealerHand = deck.dealHand();
                    playerHand = deck.dealHand();
                    
                    // send cards back to client
                    PokerInfo cardInfo = new PokerInfo();
                    cardInfo.setAction("DEAL_CARDS");
                    cardInfo.setPlayerHand(playerHand);
                    cardInfo.setDealerHand(dealerHand);
                    out.writeObject(cardInfo);
                    out.flush();
                    
                    // show what client bet
                    Platform.runLater(() -> {
                        controller.addMessage("Client #" + clientId + " - Ante: $" + betInfo.getAnteBet() + 
                                                   ", Pair Plus: $" + betInfo.getPairPlusBet());
                    });
                }
                else if (betInfo.getAction().equals("FOLD")) {
                    // client folded, they lose their bets
                    int loss = betInfo.getAnteBet() + betInfo.getPairPlusBet();
                    
                    PokerInfo resultInfo = new PokerInfo();
                    resultInfo.setAction("GAME_RESULT");
                    resultInfo.setWinnings(-loss);
                    resultInfo.setMessage("You folded. Lost $" + loss);
                    out.writeObject(resultInfo);
                    out.flush();
                    
                    Platform.runLater(() -> {
                        controller.addMessage("Client #" + clientId + " folded - Lost: $" + loss);
                    });
                }
                else if (betInfo.getAction().equals("PLAY")) {
                    // client wants to play
                    int anteBet = betInfo.getAnteBet();
                    int playBet = betInfo.getPlayBet();
                    int pairPlusBet = betInfo.getPairPlusBet();
                    
                    // check if dealer qualifies (queen high or better)
                    int dealerHandValue = ThreeCardLogic.evalHand(dealerHand);
                    boolean dealerQualifies = dealerHandValue >= 1 || hasQueenHigh(dealerHand);
                    
                    int totalWinnings = 0;
                    StringBuilder message = new StringBuilder();
                    
                    if (!dealerQualifies) {
                        // dealer doesn't have queen high
                        totalWinnings = playBet;
                        message.append("Dealer does not qualify. Play wager returned. ");
                    } else {
                        // compare dealer and player hands
                        int comparison = ThreeCardLogic.compareHands(dealerHand, playerHand);
                        
                        if (comparison == 2) {
                            // player wins
                            totalWinnings = (anteBet * 2) + (playBet * 2);
                            message.append("You beat the dealer! Won $").append(totalWinnings).append(". ");
                        } else if (comparison == 1) {
                            // dealer wins
                            totalWinnings = -(anteBet + playBet);
                            message.append("Dealer wins. Lost $").append(Math.abs(totalWinnings)).append(". ");
                        } else {
                            // tie
                            totalWinnings = anteBet + playBet;
                            message.append("Push. Bets returned. ");
                        }
                    }
                    
                    // check pair plus bet
                    if (pairPlusBet > 0) {
                        int ppWinnings = ThreeCardLogic.evalPPWinnings(playerHand, pairPlusBet);
                        totalWinnings += ppWinnings;
                        
                        if (ppWinnings > 0) {
                            message.append("Pair Plus won $").append(ppWinnings).append("!");
                        } else {
                            message.append("Pair Plus lost.");
                        }
                    }
                    
                    // send results back to client
                    PokerInfo resultInfo = new PokerInfo();
                    resultInfo.setAction("GAME_RESULT");
                    resultInfo.setWinnings(totalWinnings);
                    resultInfo.setMessage(message.toString());
                    resultInfo.setDealerHand(dealerHand);
                    out.writeObject(resultInfo);
                    out.flush();
                    
                    int finalWinnings = totalWinnings;
                    Platform.runLater(() -> {
                        controller.addMessage("Client #" + clientId + " - " + message.toString() + 
                                                   " Total: $" + finalWinnings);
                    });
                }
                else if (betInfo.getAction().equals("NEW_GAME")) {
                    // client wants to play again
                    deck = new Deck();
                    Platform.runLater(() -> {
                        controller.addMessage("Client #" + clientId + " starting new game");
                    });
                }
                else if (betInfo.getAction().equals("DISCONNECT")) {
                    break;
                }
            }
            
        } catch (Exception e) {
            System.out.println("Client #" + clientId + " disconnected");
        } finally {
            try {
                socket.close();
                Platform.runLater(() -> {
                    controller.addMessage("Client #" + clientId + " disconnected");
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    // check if dealer has queen or better
    private boolean hasQueenHigh(ArrayList<Card> hand) {
        for (Card card : hand) {
            if (card.getValue() >= 12) {
                return true;
            }
        }
        return false;
    }
}