import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

public class MyTest {
    
    // test if straight flush works
    @Test
    public void testStraightFlush() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 5));
        hand.add(new Card('H', 6));
        hand.add(new Card('H', 7));
        
        assertEquals(5, ThreeCardLogic.evalHand(hand));
    }
    
    // test three of a kind
    @Test
    public void testThreeKind() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 9));
        hand.add(new Card('D', 9));
        hand.add(new Card('C', 9));
        
        assertEquals(4, ThreeCardLogic.evalHand(hand));
    }
    
    // test straight
    @Test
    public void testStraight() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 4));
        hand.add(new Card('D', 5));
        hand.add(new Card('C', 6));
        
        assertEquals(3, ThreeCardLogic.evalHand(hand));
    }
    
    // test flush
    @Test
    public void testFlush() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('S', 2));
        hand.add(new Card('S', 7));
        hand.add(new Card('S', 10));
        
        assertEquals(2, ThreeCardLogic.evalHand(hand));
    }
    
    // test pair
    @Test
    public void testPair() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 8));
        hand.add(new Card('D', 8));
        hand.add(new Card('C', 3));
        
        assertEquals(1, ThreeCardLogic.evalHand(hand));
    }
    
    // test high card only
    @Test
    public void testHighCard() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 2));
        hand.add(new Card('D', 7));
        hand.add(new Card('C', 11));
        
        assertEquals(0, ThreeCardLogic.evalHand(hand));
    }
    
    // test pair plus pays 40 to 1 for straight flush
    @Test
    public void testPPStraightFlush() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('D', 8));
        hand.add(new Card('D', 9));
        hand.add(new Card('D', 10));
        
        assertEquals(200, ThreeCardLogic.evalPPWinnings(hand, 5));
    }
    
    // test pair plus pays 30 to 1 for three of kind
    @Test
    public void testPPThreeKind() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 7));
        hand.add(new Card('D', 7));
        hand.add(new Card('S', 7));
        
        assertEquals(150, ThreeCardLogic.evalPPWinnings(hand, 5));
    }
    
    // test pair plus pays 6 to 1 for straight
    @Test
    public void testPPStraight() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 3));
        hand.add(new Card('D', 4));
        hand.add(new Card('C', 5));
        
        assertEquals(30, ThreeCardLogic.evalPPWinnings(hand, 5));
    }
    
    // test pair plus pays 3 to 1 for flush
    @Test
    public void testPPFlush() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('C', 2));
        hand.add(new Card('C', 9));
        hand.add(new Card('C', 13));
        
        assertEquals(15, ThreeCardLogic.evalPPWinnings(hand, 5));
    }
    
    // test pair plus pays 1 to 1 for pair
    @Test
    public void testPPPair() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 6));
        hand.add(new Card('D', 6));
        hand.add(new Card('S', 2));
        
        assertEquals(5, ThreeCardLogic.evalPPWinnings(hand, 5));
    }
    
    // test pair plus loses when no pair
    @Test
    public void testPPLoss() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card('H', 2));
        hand.add(new Card('D', 5));
        hand.add(new Card('C', 9));
        
        assertEquals(-5, ThreeCardLogic.evalPPWinnings(hand, 5));
    }
    
    // test player wins with better hand
    @Test
    public void testPlayerWins() {
        ArrayList<Card> dealer = new ArrayList<>();
        dealer.add(new Card('H', 2));
        dealer.add(new Card('D', 5));
        dealer.add(new Card('C', 8));
        
        ArrayList<Card> player = new ArrayList<>();
        player.add(new Card('S', 9));
        player.add(new Card('H', 9));
        player.add(new Card('D', 3));
        
        assertEquals(2, ThreeCardLogic.compareHands(dealer, player));
    }
    
    // test dealer wins with better hand
    @Test
    public void testDealerWins() {
        ArrayList<Card> dealer = new ArrayList<>();
        dealer.add(new Card('H', 10));
        dealer.add(new Card('D', 10));
        dealer.add(new Card('C', 5));
        
        ArrayList<Card> player = new ArrayList<>();
        player.add(new Card('S', 3));
        player.add(new Card('H', 7));
        player.add(new Card('D', 11));
        
        assertEquals(1, ThreeCardLogic.compareHands(dealer, player));
    }
    
    // test tie when same hand
    @Test
    public void testTie() {
        ArrayList<Card> dealer = new ArrayList<>();
        dealer.add(new Card('H', 6));
        dealer.add(new Card('D', 6));
        dealer.add(new Card('C', 4));
        
        ArrayList<Card> player = new ArrayList<>();
        player.add(new Card('S', 6));
        player.add(new Card('C', 6));
        player.add(new Card('D', 4));
        
        assertEquals(0, ThreeCardLogic.compareHands(dealer, player));
    }
    
    // test deck deals 3 cards
    @Test
    public void testDealHand() {
        Deck deck = new Deck();
        ArrayList<Card> hand = deck.dealHand();
        
        assertEquals(3, hand.size());
    }
    
    // test deck has 52 cards total
    @Test
    public void testFullDeck() {
        Deck deck = new Deck();
        int cardCount = 0;
        
        // deal 17 hands to use all 51 cards
        for (int i = 0; i < 17; i++) {
            ArrayList<Card> hand = deck.dealHand();
            cardCount += hand.size();
        }
        
        // should have dealt 51 cards
        assertEquals(51, cardCount);
    }
    
    // test card has right suit
    @Test
    public void testCardSuit() {
        Card card = new Card('H', 14);
        assertEquals('H', card.getSuit());
    }
    
    // test card has right value
    @Test
    public void testCardValue() {
        Card card = new Card('D', 10);
        assertEquals(10, card.getValue());
    }
    
    // test ace card toString
    @Test
    public void testAceString() {
        Card card = new Card('S', 14);
        assertEquals("AS", card.toString());
    }
    
    // test king card toString
    @Test
    public void testKingString() {
        Card card = new Card('C', 13);
        assertEquals("KC", card.toString());
    }
}